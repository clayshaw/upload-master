module EXE_MEM(
    input clk,
    input rst_n,
    
    // Control Signals
    input RegWriteE,
    input [1:0] MemtoRegE,
    input MemWriteE,
    
    // Data Signals
    input [31:0] ALUResultE,
    input [31:0] WriteDataE, // 這是 rs2 的值 (read_data2E)
    input [4:0]  RdE,
    input [31:0] PCPlus4E,   // 用於 JAL/JALR 寫回 PC+4
    
    // Output to MEM stage
    output reg RegWriteM,
    output reg [1:0] MemtoRegM,
    output reg MemWriteM,
    output reg [31:0] ALUResultM,
    output reg [31:0] WriteDataM,
    output reg [4:0]  RdM,
    output reg [31:0] PCPlus4M
);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        RegWriteM  <= 1'b0;
        MemtoRegM  <= 2'b00;
        MemWriteM  <= 1'b0;
        ALUResultM <= 32'd0;
        WriteDataM <= 32'd0;
        RdM        <= 5'd0;
        PCPlus4M   <= 32'd0;
    end else begin
        RegWriteM  <= RegWriteE;
        MemtoRegM  <= MemtoRegE;
        MemWriteM  <= MemWriteE;
        ALUResultM <= ALUResultE;
        WriteDataM <= WriteDataE;
        RdM        <= RdE;
        PCPlus4M   <= PCPlus4E;
    end
end
endmodule