module Instruction_Memory(
	input	[31:0]PCF,
	output[31:0]instrF
);

reg [31:0] rom [1023:0];

initial begin
	$readmemh("Instruction.txt",rom);
end

assign instrF = rom[PCF[31:2]];


endmodule 