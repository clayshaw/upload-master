module Control_Unit(
    // --- 輸入訊號 (來自 Instruction) ---
    input  [6:0] opcode,
    input  [2:0] funct3,
    input        Instruction_30, // instruction[30]，用來區分 ADD/SUB, SRL/SRA
    
    // --- 輸出控制訊號 ---
    output reg       RegWrite,    // 是否寫入 RegFile
    output reg       ALUSrc,      // ALU 第二輸入源 (0: rs2, 1: Immediate)
	 output reg       ALUSrcA,
    output reg       MemRead,     // 是否讀取 Data Memory
    output reg       MemWrite,    // 是否寫入 Data Memory
    output reg       Branch,      // 是否為條件跳躍指令 (BEQ, BNE...)
    output reg       Jump,        // 是否為無條件跳躍指令 (JAL, JALR)
	 output reg       Jalr,
    output reg [1:0] MemtoReg,    // 寫回 RegFile 的資料源 (00:ALU, 01:Mem, 10:PC+4)
    
    // --- 連接到上一關 ALU_32bit 的控制線 ---
    output reg [3:0] ALUControl, // 丟給 ALU 的 4-bit 運算碼
    output reg [1:0] Control      // 丟給 ALU 的擴充控制 (如 2'b01 用於 LUI)
);

    // 定義 RISC-V RV32I 的標準 Opcode 編碼
    localparam OP_R_TYPE  = 7'b0110011;
    localparam OP_I_ALU   = 7'b0010011;
    localparam OP_LOAD    = 7'b0000011;
    localparam OP_STORE   = 7'b0100011;
    localparam OP_BRANCH  = 7'b1100011;
    localparam OP_LUI     = 7'b0110111;
    localparam OP_AUIPC   = 7'b0010111;
    localparam OP_JAL     = 7'b1101111;
    localparam OP_JALR    = 7'b1100111;

    always @(*) begin
        // 【關鍵】預設所有控制訊號為 0，避免合成出不必要的 Latch
        RegWrite    = 1'b0;
        ALUSrc      = 1'b0;
        ALUSrcA     = 1'b0;  // 預設來自 rs1
        MemRead     = 1'b0;
        MemWrite    = 1'b0;
        Branch      = 1'b0;
        Jump        = 1'b0;
        Jalr        = 1'b0;  // 預設不是 JALR
        MemtoReg    = 2'b00;
        ALUControl  = 4'b0010;
        Control     = 2'b00;

        case (opcode)
            // ==========================================
            // 1. R-Type 指令 (add, sub, sll, slt...)
            // ==========================================
            OP_R_TYPE: begin
                RegWrite = 1'b1; // 需要寫回暫存器
                
                // 根據 funct3 與 Instruction_30 決定 ALU 運算碼
                case (funct3)
                    3'b000: ALUControl = (Instruction_30) ? 4'b0110 : 4'b0010; // SUB : ADD
                    3'b001: ALUControl = 4'b0100; // SLL (邏輯左移)
                    3'b010: ALUControl = 4'b0111; // SLT (有號數比較)
                    3'b011: ALUControl = 4'b1000; // SLTU (無號數比較)
                    3'b100: ALUControl = 4'b0011; // XOR
                    3'b101: ALUControl = (Instruction_30) ? 4'b1101 : 4'b0101; // SRA : SRL
                    3'b110: ALUControl = 4'b0001; // OR
                    3'b111: ALUControl = 4'b0000; // AND
                endcase
            end

            // ==========================================
            // 2. I-Type ALU 指令 (addi, slli, xori...)
            // ==========================================
            OP_I_ALU: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1; // 第二個運算元來自立即數 (Immediate)
                
                case (funct3)
                    3'b000: ALUControl = 4'b0010; // ADDI
                    3'b001: ALUControl = 4'b0100; // SLLI
                    3'b010: ALUControl = 4'b0111; // SLTI
                    3'b011: ALUControl = 4'b1000; // SLTIU
                    3'b100: ALUControl = 4'b0011; // XORI
                    3'b101: ALUControl = (Instruction_30) ? 4'b1101 : 4'b0101; // SRAI : SRLI
                    3'b110: ALUControl = 4'b0001; // ORI
                    3'b111: ALUControl = 4'b0000; // ANDI
                endcase
            end

            // ==========================================
            // 3. Load 指令 (lw, lb, lh)
            // ==========================================
            OP_LOAD: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1; // 計算記憶體位址: Base Reg + Imm
                MemRead  = 1'b1; // 啟動記憶體讀取
                MemtoReg = 2'b01; // 寫回暫存器的資料來自 Memory
            end

            // ==========================================
            // 4. Store 指令 (sw, sb, sh)
            // ==========================================
            OP_STORE: begin
                ALUSrc   = 1'b1; // 計算記憶體位址: Base Reg + Imm
                MemWrite = 1'b1; // 啟動記憶體寫入
            end

            // ==========================================
            // 5. Branch 指令 (beq, bne, blt...)
            // ==========================================
            OP_BRANCH: begin
                Branch   = 1'b1;
            end

            // ==========================================
            // 6. LUI 指令 (Load Upper Immediate)
            // ==========================================
            OP_LUI: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                Control  = 2'b01; // 觸發上一關 ALU 的特殊機制：直接輸出 data2 (立即數)
            end
				
				 // ==========================================
            // 7. AUIPC 指令 
            // ==========================================
				OP_AUIPC: begin 
                RegWrite = 1'b1;
                ALUSrcA  = 1'b1; // 第一輸入源為 PC
                ALUSrc   = 1'b1; // 第二輸入源為 Imm
                ALUControl = 4'b0010; // 執行 PC + Imm
            end
				
				// ==========================================
            // 7. OP_JAL 指令 
            // ==========================================
				OP_JAL: begin
                RegWrite = 1'b1;
                Jump     = 1'b1;
                MemtoReg = 2'b10;
            end

            // ==========================================
            // 8. Jump 指令 (JAL )
            // ==========================================
            OP_JALR: begin 
                RegWrite = 1'b1;
                Jump     = 1'b1;
                Jalr     = 1'b1; // 啟動 JALR 的位址計算機制
                MemtoReg = 2'b10;
            end

            default: begin
                // 未定義的 Opcode，維持預設值 0
            end
        endcase
    end

endmodule