library verilog;
use verilog.vl_types.all;
entity Instruction_Memory is
    port(
        PCF             : in     vl_logic_vector(31 downto 0);
        instrF          : out    vl_logic_vector(31 downto 0)
    );
end Instruction_Memory;
