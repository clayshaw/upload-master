library verilog;
use verilog.vl_types.all;
entity IF_ID is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        StallD          : in     vl_logic;
        FlushD          : in     vl_logic;
        PCF             : in     vl_logic_vector(31 downto 0);
        PCPlus4F        : in     vl_logic_vector(31 downto 0);
        instrF          : in     vl_logic_vector(31 downto 0);
        PCD             : out    vl_logic_vector(31 downto 0);
        PCPlus4D        : out    vl_logic_vector(31 downto 0);
        instrD          : out    vl_logic_vector(31 downto 0)
    );
end IF_ID;
