library verilog;
use verilog.vl_types.all;
entity ALU_32bit is
    port(
        ALU_Control     : in     vl_logic_vector(3 downto 0);
        Control         : in     vl_logic_vector(1 downto 0);
        data1           : in     vl_logic_vector(31 downto 0);
        data2           : in     vl_logic_vector(31 downto 0);
        result          : out    vl_logic_vector(31 downto 0);
        zero            : out    vl_logic;
        negative        : out    vl_logic
    );
end ALU_32bit;
