library verilog;
use verilog.vl_types.all;
entity MEM_WB is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        RegWriteM       : in     vl_logic;
        MemtoRegM       : in     vl_logic_vector(1 downto 0);
        ALUResultM      : in     vl_logic_vector(31 downto 0);
        ReadDataM       : in     vl_logic_vector(31 downto 0);
        RdM             : in     vl_logic_vector(4 downto 0);
        PCPlus4M        : in     vl_logic_vector(31 downto 0);
        RegWriteW       : out    vl_logic;
        MemtoRegW       : out    vl_logic_vector(1 downto 0);
        ALUResultW      : out    vl_logic_vector(31 downto 0);
        ReadDataW       : out    vl_logic_vector(31 downto 0);
        RdW             : out    vl_logic_vector(4 downto 0);
        PCPlus4W        : out    vl_logic_vector(31 downto 0)
    );
end MEM_WB;
