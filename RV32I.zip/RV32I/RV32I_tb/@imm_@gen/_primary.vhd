library verilog;
use verilog.vl_types.all;
entity Imm_Gen is
    port(
        instr           : in     vl_logic_vector(31 downto 0);
        imm             : out    vl_logic_vector(31 downto 0)
    );
end Imm_Gen;
