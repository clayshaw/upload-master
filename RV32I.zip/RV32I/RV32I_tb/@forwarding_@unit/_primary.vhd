library verilog;
use verilog.vl_types.all;
entity Forwarding_Unit is
    port(
        Rs1E            : in     vl_logic_vector(4 downto 0);
        Rs2E            : in     vl_logic_vector(4 downto 0);
        RdM             : in     vl_logic_vector(4 downto 0);
        RegWriteM       : in     vl_logic;
        RdW             : in     vl_logic_vector(4 downto 0);
        RegWriteW       : in     vl_logic;
        ForwardAE       : out    vl_logic_vector(1 downto 0);
        ForwardBE       : out    vl_logic_vector(1 downto 0)
    );
end Forwarding_Unit;
