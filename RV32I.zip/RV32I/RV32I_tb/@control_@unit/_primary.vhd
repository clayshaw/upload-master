library verilog;
use verilog.vl_types.all;
entity Control_Unit is
    port(
        opcode          : in     vl_logic_vector(6 downto 0);
        funct3          : in     vl_logic_vector(2 downto 0);
        Instruction_30  : in     vl_logic;
        RegWrite        : out    vl_logic;
        ALUSrc          : out    vl_logic;
        ALUSrcA         : out    vl_logic;
        MemRead         : out    vl_logic;
        MemWrite        : out    vl_logic;
        Branch          : out    vl_logic;
        Jump            : out    vl_logic;
        Jalr            : out    vl_logic;
        MemtoReg        : out    vl_logic_vector(1 downto 0);
        ALUControl      : out    vl_logic_vector(3 downto 0);
        Control         : out    vl_logic_vector(1 downto 0)
    );
end Control_Unit;
