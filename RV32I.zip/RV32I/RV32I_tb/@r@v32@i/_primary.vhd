library verilog;
use verilog.vl_types.all;
entity RV32I is
    port(
        CLOCK_50        : in     vl_logic;
        rst_n           : in     vl_logic;
        SW              : in     vl_logic_vector(17 downto 0);
        KEY             : in     vl_logic_vector(3 downto 1);
        UART_RXD        : in     vl_logic;
        LEDR            : out    vl_logic_vector(17 downto 0);
        LEDG            : out    vl_logic_vector(8 downto 0);
        HEX0            : out    vl_logic_vector(6 downto 0);
        HEX1            : out    vl_logic_vector(6 downto 0);
        HEX2            : out    vl_logic_vector(6 downto 0);
        HEX3            : out    vl_logic_vector(6 downto 0);
        UART_TXD        : out    vl_logic
    );
end RV32I;
