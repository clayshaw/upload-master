library verilog;
use verilog.vl_types.all;
entity ProgramCounter is
    generic(
        RESET_VECTOR    : integer := 0;
        OS_VECTOR       : vl_logic_vector(31 downto 0) := (Hi1, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0)
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        PCWrite         : in     vl_logic;
        next_pc         : in     vl_logic_vector(31 downto 0);
        PCF             : out    vl_logic_vector(31 downto 0)
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of RESET_VECTOR : constant is 1;
    attribute mti_svvh_generic_type of OS_VECTOR : constant is 1;
end ProgramCounter;
