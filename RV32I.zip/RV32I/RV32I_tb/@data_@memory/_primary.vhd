library verilog;
use verilog.vl_types.all;
entity Data_Memory is
    port(
        clk             : in     vl_logic;
        MemWrite        : in     vl_logic;
        ByteEnable      : in     vl_logic_vector(3 downto 0);
        Addr            : in     vl_logic_vector(31 downto 0);
        Write_Data      : in     vl_logic_vector(31 downto 0);
        Read_Data       : out    vl_logic_vector(31 downto 0)
    );
end Data_Memory;
