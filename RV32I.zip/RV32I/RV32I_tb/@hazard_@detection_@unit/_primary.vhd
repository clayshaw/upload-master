library verilog;
use verilog.vl_types.all;
entity Hazard_Detection_Unit is
    port(
        Rs1D            : in     vl_logic_vector(4 downto 0);
        Rs2D            : in     vl_logic_vector(4 downto 0);
        RdE             : in     vl_logic_vector(4 downto 0);
        MemtoRegE       : in     vl_logic_vector(1 downto 0);
        PCSrcE          : in     vl_logic;
        PCWrite         : out    vl_logic;
        StallD          : out    vl_logic;
        FlushD          : out    vl_logic;
        FlushE          : out    vl_logic
    );
end Hazard_Detection_Unit;
