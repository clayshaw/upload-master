library verilog;
use verilog.vl_types.all;
entity EXE_MEM is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        RegWriteE       : in     vl_logic;
        MemtoRegE       : in     vl_logic_vector(1 downto 0);
        MemWriteE       : in     vl_logic;
        ALUResultE      : in     vl_logic_vector(31 downto 0);
        WriteDataE      : in     vl_logic_vector(31 downto 0);
        RdE             : in     vl_logic_vector(4 downto 0);
        PCPlus4E        : in     vl_logic_vector(31 downto 0);
        RegWriteM       : out    vl_logic;
        MemtoRegM       : out    vl_logic_vector(1 downto 0);
        MemWriteM       : out    vl_logic;
        ALUResultM      : out    vl_logic_vector(31 downto 0);
        WriteDataM      : out    vl_logic_vector(31 downto 0);
        RdM             : out    vl_logic_vector(4 downto 0);
        PCPlus4M        : out    vl_logic_vector(31 downto 0)
    );
end EXE_MEM;
