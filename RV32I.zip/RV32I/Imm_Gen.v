module Imm_Gen(
    input  [31:0] instr,
    output reg [31:0] imm
);

    wire [6:0] opcode = instr[6:0];

    // 定義 Opcode
    localparam OP_I_ALU  = 7'b0010011;
    localparam OP_LOAD   = 7'b0000011;
    localparam OP_JALR   = 7'b1100111;
    localparam OP_STORE  = 7'b0100011;
    localparam OP_BRANCH = 7'b1100011;
    localparam OP_LUI    = 7'b0110111;
    localparam OP_AUIPC  = 7'b0010111;
    localparam OP_JAL    = 7'b1101111;

    always @(*) begin
        case (opcode)
            // 1. I-Type (addi, lw, jalr...) -> 取 [31:20]
            OP_I_ALU, OP_LOAD, OP_JALR: begin
                imm = {{20{instr[31]}}, instr[31:20]}; // 最高位元 instr[31] 複製 20 次做符號擴充
            end
            
            // 2. S-Type (sw, sb...) -> 取 [31:25] 拼接 [11:7]
            OP_STORE: begin
                imm = {{20{instr[31]}}, instr[31:25], instr[11:7]};
            end
            
            // 3. B-Type (beq, bne...) -> 取 [31], [7], [30:25], [11:8]，最低位補 0
            OP_BRANCH: begin
                imm = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0};
            end
            
            // 4. U-Type (lui, auipc) -> 取 [31:12]，低 12 位補 0
            OP_LUI, OP_AUIPC: begin
                imm = {instr[31:12], 12'b0};
            end
            
            // 5. J-Type (jal) -> 取 [31], [19:12], [20], [30:21]，最低位補 0
            OP_JAL: begin
                imm = {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0};
            end
            
            // 預設值 (R-Type 等不需要立即數的指令)
            default: imm = 32'd0;
        endcase
    end

endmodule