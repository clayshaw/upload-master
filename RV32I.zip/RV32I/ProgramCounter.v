module ProgramCounter(
    input             clk,
    input             rst_n,       
    input             PCWrite,     
    input      [31:0] next_pc,     
    output reg [31:0] PCF 
);


parameter RESET_VECTOR = 32'h0000_0000;
parameter OS_VECTOR 	  = 32'h8000_0000;

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		PCF <= RESET_VECTOR;    
	end else if (PCWrite) begin
		PCF <= next_pc;    
	end
end

endmodule