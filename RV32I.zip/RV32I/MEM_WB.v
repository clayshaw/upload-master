module MEM_WB(
    input clk,
    input rst_n,
    
    // Control Signals
    input RegWriteM,
    input [1:0] MemtoRegM,
    
    // Data Signals
    input [31:0] ALUResultM,
    input [31:0] ReadDataM,  // 從 Data Memory 讀出的資料
    input [4:0]  RdM,
    input [31:0] PCPlus4M,
    
    // Output to WB stage
    output reg RegWriteW,
    output reg [1:0] MemtoRegW,
    output reg [31:0] ALUResultW,
    output reg [31:0] ReadDataW,
    output reg [4:0]  RdW,
    output reg [31:0] PCPlus4W
);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        RegWriteW  <= 1'b0;
        MemtoRegW  <= 2'b00;
        ALUResultW <= 32'd0;
        ReadDataW  <= 32'd0;
        RdW        <= 5'd0;
        PCPlus4W   <= 32'd0;
    end else begin
        RegWriteW  <= RegWriteM;
        MemtoRegW  <= MemtoRegM;
        ALUResultW <= ALUResultM;
        ReadDataW  <= ReadDataM;
        RdW        <= RdM;
        PCPlus4W   <= PCPlus4M;
    end
end
endmodule