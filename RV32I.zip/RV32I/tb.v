`timescale 1ns/1ps

module tb_RV32I();

    // 訊號宣告
    reg         CLOCK_50;
    reg         rst_n;
    reg  [17:0] SW;
    reg  [3:1]  KEY;
    reg         UART_RXD;
    
    wire [17:0] LEDR;
    wire [8:0]  LEDG;
    wire [6:0]  HEX0, HEX1, HEX2, HEX3;
    wire        UART_TXD;

    // 實例化 CPU 頂層模組
    RV32I uut (
        .CLOCK_50(CLOCK_50),
        .rst_n(rst_n),
        .SW(SW),
        .KEY(KEY),
        .UART_RXD(UART_RXD),
        .LEDR(LEDR),
        .LEDG(LEDG),
        .HEX0(HEX0),
        .HEX1(HEX1),
        .HEX2(HEX2),
        .HEX3(HEX3),
        .UART_TXD(UART_TXD)
    );

    // 產生 Clock (50MHz)
    initial begin
        CLOCK_50 = 0;
        forever #10 CLOCK_50 = ~CLOCK_50; 
    end

    // 測試流程初始化
    initial begin
        rst_n = 1'b0;
        SW = 18'd0;
        KEY = 3'b111;
        UART_RXD = 1'b1;

        #100;
        rst_n = 1'b1; // 釋放 Reset
        
        // 防呆機制：如果跑了 5000ns 還沒結束，代表 CPU 卡死了
        #5000;
        $display("\n===========================================");
        $display("   ⚠️ TIMEOUT! 程式陷入未知無窮迴圈  ");
        $display("===========================================\n");
        $stop; 
    end

    // =========================================================
    // 自我驗證監控器 (Self-Checking Monitor)
    // 盯著 uut.RF.x[31] 的值，判斷測試結果
    // =========================================================
    always @(posedge CLOCK_50) begin
        if (uut.RF.x[31] == 32'd1) begin
            $display("\n=======================================================");
            $display("   🎉 完美通關 (PASS) !");
            $display("   你的 RV32I 處理器成功執行了 ALU, 前遞, 讀寫與所有跳躍邏輯！ ");
            $display("=======================================================\n");
            $stop;
        end else if (uut.RF.x[31] == 32'hFFFFFFFF) begin
            $display("\n=======================================================");
            $display("   ❌ 測試失敗 (FAIL) !");
            $display("   處理器掉入了錯誤陷阱，請檢查波形圖中的 Branch 或 Jump 邏輯。 ");
            $display("=======================================================\n");
            $stop;
        end
    end

    // 選用：若想觀察各暫存器即時變化，可解除註解下方
    /*
    initial begin
        $monitor("Time: %5t | PC: 0x%08h | x3: %d | x11: %d", $time, uut.PCF, uut.RF.x[3], uut.RF.x[11]);
    end
    */

endmodule