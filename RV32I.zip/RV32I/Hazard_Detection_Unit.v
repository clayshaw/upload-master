module Hazard_Detection_Unit(
    input [4:0] Rs1D,
    input [4:0] Rs2D,
    input [4:0] RdE,
    input [1:0] MemtoRegE, // 2'b01 代表 EXE 階段是 Load 指令
    input       PCSrcE,    // Branch 成功跳躍或 Jump 觸發
    output reg  PCWrite,   // 保持 PC 不變
    output reg  StallD,    // 凍結 IF/ID 管線暫存器
    output reg  FlushD,    // 清除 IF/ID (插入 NOP)
    output reg  FlushE     // 清除 ID/EXE (插入 Bubble)
);
    always @(*) begin
        // 預設正常運行，無停頓、無清除
        PCWrite = 1'b1;
        StallD  = 1'b0;
        FlushD  = 1'b0;
        FlushE  = 1'b0;
        
        // 1. Load-Use Hazard 偵測
        // 當前一動是 Load，且其寫入目標暫存器等於目前解碼階段需要讀取的暫存器
        if ((MemtoRegE == 2'b01) && (RdE != 5'd0) && ((RdE == Rs1D) || (RdE == Rs2D))) begin
            PCWrite = 1'b0; // 凍結 PC
            StallD  = 1'b1; // 凍結 IF/ID
            FlushE  = 1'b1; // 於 ID/EXE 插入 Bubble (清除控制訊號)
        end
        
        // 2. Control Hazard 偵測 (Branch/Jump Flush)
        // 如果在 EXE 階段確認要跳躍，必須清除正在 IF 與 ID 階段的錯誤指令
        if (PCSrcE) begin
            FlushD = 1'b1;
            FlushE = 1'b1;
        end
    end
endmodule