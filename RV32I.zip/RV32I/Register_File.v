module Register_File(
	input 		clk,
	input 		rst_n,
	input			RegWrite,
	input [4:0]	rs1,
	input [4:0]	rs2,
	input [4:0]	rd,
	input [31:0]write_data,
	output[31:0]read_data1,
	output[31:0]read_data2
);

// Register x0-x31
reg [31:0] x[31:0];
integer i;

// RISC-V 規定 x0 永遠為 0
// 加入內部前遞 (Internal Forwarding): 解決同週期 Write-After-Read 問題
assign read_data1 = (rs1 == 5'd0) ? 32'd0 : 
                    (RegWrite && (rd == rs1)) ? write_data : 
                    x[rs1];

assign read_data2 = (rs2 == 5'd0) ? 32'd0 : 
                    (RegWrite && (rd == rs2)) ? write_data : 
                    x[rs2];

always @(posedge clk or negedge rst_n)begin
	if(!rst_n)begin
		for(i = 0;i<32;i = i + 1)begin
			x[i] <= 32'd0;
		end
	end else begin
		// $zero不可寫入
		if(RegWrite && (rd != 5'd0))begin
			x[rd] <= write_data;
		end
	end
end	

endmodule 