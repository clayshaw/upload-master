module ALU_32bit(
    input [3:0]     ALU_Control, 
    input [1:0]     Control,     
    input [31:0]    data1,       
    input [31:0]    data2,       
    output[31:0]    result,      
    output		     zero,negative        
);

    reg [31:0] alu_out;

    assign result = alu_out;
    
    assign zero   	= (result == 32'd0);
	 assign negative 	= result[31];

    always @(*) begin
        if (Control == 2'b01) begin
            alu_out = data2;
        end 
        else begin
            case(ALU_Control)
                4'b0000: alu_out = data1 & data2;                    
                4'b0001: alu_out = data1 | data2;                    
                4'b0010: alu_out = data1 + data2;                     
                4'b0110: alu_out = data1 - data2;                    
                4'b0011: alu_out = data1 ^ data2;                     
                
                4'b0100: alu_out = data1 << data2[4:0];				//logic
                4'b0101: alu_out = data1 >> data2[4:0];           //logic
                4'b1101: alu_out = $signed(data1) >>> data2[4:0]; //arithmetic 
                
                4'b0111: alu_out = ($signed(data1) < $signed(data2)) ? 32'd1 : 32'd0;   
                4'b1000: alu_out = (data1 < data2) ? 32'd1 : 32'd0;                     
                
                default: alu_out = 32'd0;                             
            endcase
        end
    end

endmodule