module RV32I (
    input         CLOCK_50,    
    input         rst_n,       
    input  [17:0] SW,          
    input  [3:1]  KEY,         
    input         UART_RXD,    
    output [17:0] LEDR,        
    output [8:0]  LEDG,        
    output [6:0]  HEX0,        
    output [6:0]  HEX1,        
    output [6:0]  HEX2,        
    output [6:0]  HEX3,        
    output        UART_TXD     
);

// 全域訊號與管線連線宣告
wire PCWrite, StallD, FlushD, FlushE;
wire [1:0] ForwardAE, ForwardBE;

wire [31:0] PCD, PCPlus4D, instrD;

// --- ID to EXE ---
wire        RegWriteE, ALUSrcE, MemWriteE, BranchE, JumpE;
wire        ALUSrcAE, JalrE;     
wire [2:0]  funct3E;             
wire [1:0]  MemtoRegE;
wire [3:0]  ALUControlE;
wire [1:0]  ControlE;
wire [31:0] read_data1E, read_data2E, immE, PCE;
wire [4:0]  rs1E, rs2E, rdE;

// --- EXE to MEM ---
wire        RegWriteM, MemWriteM;
wire [1:0]  MemtoRegM;
wire [31:0] ALUResultM, WriteDataM, PCPlus4M;
wire [4:0]  rdM;

// --- MEM to WB ---
wire        RegWriteW;
wire [1:0]  MemtoRegW;
wire [31:0] ALUResultW, ReadDataW, PCPlus4W;
wire [4:0]  rdW;
wire [31:0] ResultW;

// =========================================================
// 1. IF 階段
// =========================================================
wire [31:0] next_pc, PCF, instrF;
wire [31:0] PCPlus4F = PCF + 4;

ProgramCounter PC(.clk(CLOCK_50), .rst_n(rst_n), .PCWrite(PCWrite), .next_pc(next_pc), .PCF(PCF));
Instruction_Memory IM_inst(.PCF(PCF), .instrF(instrF));
IF_ID FD(.clk(CLOCK_50), .rst_n(rst_n), .StallD(StallD), .FlushD(FlushD), .PCF(PCF), .PCPlus4F(PCPlus4F), .instrF(instrF), .PCD(PCD), .PCPlus4D(PCPlus4D), .instrD(instrD));

// =========================================================
// 2. ID 階段
// =========================================================
wire [4:0]  rs1          = instrD[19:15];
wire [4:0]  rs2          = instrD[24:20];
wire [4:0]  rd           = instrD[11:7];
wire [6:0]  opcode       = instrD[6:0];
wire [2:0]  funct3       = instrD[14:12];
wire        Instruction_30 = instrD[30];

wire       RegWriteD, ALUSrcD, MemWriteD, BranchD, JumpD, ALUSrcAD, JalrD,MemReadD;        
wire [1:0] MemtoRegD, ControlD;   
wire [3:0] ALUControlD; 
wire [31:0] read_data1, read_data2, immD;

Register_File RF(.clk(CLOCK_50), .rst_n(rst_n), .RegWrite(RegWriteW), .rs1(rs1), .rs2(rs2), .rd(rdW), .write_data(ResultW), .read_data1(read_data1), .read_data2(read_data2));

Control_Unit CU(
    .opcode(opcode), .funct3(funct3), .Instruction_30(Instruction_30),
    .RegWrite(RegWriteD), .ALUSrc(ALUSrcD), .ALUSrcA(ALUSrcAD), .MemWrite(MemWriteD),.MemRead(MemReadD), 
    .Branch(BranchD), .Jump(JumpD), .Jalr(JalrD),
    .MemtoReg(MemtoRegD), .ALUControl(ALUControlD), .Control(ControlD)
);

Imm_Gen ImmGen_inst(.instr(instrD), .imm(immD));

ID_EXE ID_EXE_inst(
    .clk(CLOCK_50), .rst_n(rst_n), .FlushE(FlushE),     
    .RegWriteD(RegWriteD), .MemtoRegD(MemtoRegD), .MemWriteD(MemWriteD), .JumpD(JumpD), .BranchD(BranchD),
    .ALUSrcAD(ALUSrcAD), .JalrD(JalrD), .ALUControlD(ALUControlD), .ControlD(ControlD), .ALUSrcD(ALUSrcD), .funct3D(funct3),
    .read_data1D(read_data1), .read_data2D(read_data2), .PCD(PCD), .Rs1D(rs1), .Rs2D(rs2), .RdD(rd), .immExD(immD),
    
    .RegWriteE(RegWriteE), .MemtoRegE(MemtoRegE), .MemWriteE(MemWriteE), .JumpE(JumpE), .BranchE(BranchE),
    .ALUSrcAE(ALUSrcAE), .JalrE(JalrE), .ALUControlE(ALUControlE), .ControlE(ControlE), .ALUSrcE(ALUSrcE), .funct3E(funct3E),
    .read_data1E(read_data1E), .read_data2E(read_data2E), .PCE(PCE), .Rs1E(rs1E), .Rs2E(rs2E), .RdE(rdE), .immExE(immE)
);

// =========================================================
// 3. EXE 階段
// =========================================================
wire [31:0] Forwarded_SrcA_E, Forwarded_SrcB_E, SrcA_E, SrcB_E, ALUResultE;
wire        ZeroE, NegativeE;      
wire [31:0] PCPlus4E = PCE + 4;

assign Forwarded_SrcA_E = (ForwardAE == 2'b10) ? ALUResultM : (ForwardAE == 2'b01) ? ResultW : read_data1E;
assign Forwarded_SrcB_E = (ForwardBE == 2'b10) ? ALUResultM : (ForwardBE == 2'b01) ? ResultW : read_data2E;

// ALU_SrcA 可以透過 ALUSrcAE 選擇是否要吃 PC (給 AUIPC 使用)
assign SrcA_E = (ALUSrcAE) ? PCE : Forwarded_SrcA_E;
assign SrcB_E = (ALUSrcE)  ? immE : Forwarded_SrcB_E;

ALU_32bit ALU(.ALU_Control(ALUControlE), .Control(ControlE), .data1(SrcA_E), .data2(SrcB_E), .result(ALUResultE), .zero(ZeroE), .negative(NegativeE));

// 獨立的分支比較器 (Branch Comparator)
reg Branch_Condition_Met;
always @(*) begin
    case(funct3E)
        3'b000: Branch_Condition_Met = (Forwarded_SrcA_E == Forwarded_SrcB_E);                          // BEQ
        3'b001: Branch_Condition_Met = (Forwarded_SrcA_E != Forwarded_SrcB_E);                          // BNE
        3'b100: Branch_Condition_Met = ($signed(Forwarded_SrcA_E) < $signed(Forwarded_SrcB_E));         // BLT
        3'b101: Branch_Condition_Met = ($signed(Forwarded_SrcA_E) >= $signed(Forwarded_SrcB_E));        // BGE
        3'b110: Branch_Condition_Met = (Forwarded_SrcA_E < Forwarded_SrcB_E);                           // BLTU
        3'b111: Branch_Condition_Met = (Forwarded_SrcA_E >= Forwarded_SrcB_E);                          // BGEU
        default: Branch_Condition_Met = 1'b0;
    endcase
end

// 判斷是否跳躍，以及修正 JALR 目標位址的運算
wire PCSrcE = (BranchE & Branch_Condition_Met) | JumpE;
wire [31:0] PCTargetE = (JalrE) ? ((Forwarded_SrcA_E + immE) & 32'hFFFFFFFE) : (PCE + immE);
assign next_pc = (PCSrcE) ? PCTargetE : PCPlus4F;

EXE_MEM EXE_MEM_inst(
    .clk(CLOCK_50), .rst_n(rst_n), .RegWriteE(RegWriteE), .MemtoRegE(MemtoRegE), .MemWriteE(MemWriteE),
    .ALUResultE(ALUResultE), .WriteDataE(Forwarded_SrcB_E), .RdE(rdE), .PCPlus4E(PCPlus4E),
    .RegWriteM(RegWriteM), .MemtoRegM(MemtoRegM), .MemWriteM(MemWriteM),
    .ALUResultM(ALUResultM), .WriteDataM(WriteDataM), .RdM(rdM), .PCPlus4M(PCPlus4M)
);

// =========================================================
// 4. MEM 階段
// =========================================================
wire [31:0] ReadDataM;
wire [3:0]  ByteEnableM = 4'b1111;

Data_Memory DM(.clk(CLOCK_50), .MemWrite(MemWriteM), .ByteEnable(ByteEnableM), .Addr(ALUResultM), .Write_Data(WriteDataM), .Read_Data(ReadDataM));

MEM_WB MEM_WB_inst(
    .clk(CLOCK_50), .rst_n(rst_n), .RegWriteM(RegWriteM), .MemtoRegM(MemtoRegM),
    .ALUResultM(ALUResultM), .ReadDataM(ReadDataM), .RdM(rdM), .PCPlus4M(PCPlus4M),
    .RegWriteW(RegWriteW), .MemtoRegW(MemtoRegW), .ALUResultW(ALUResultW), .ReadDataW(ReadDataW), .RdW(rdW), .PCPlus4W(PCPlus4W)
);

// =========================================================
// 5. WB 階段
// =========================================================
assign ResultW = (MemtoRegW == 2'b01) ? ReadDataW :
                 (MemtoRegW == 2'b10) ? PCPlus4W  : ALUResultW;

// =========================================================
// 6. Hazard Detection & Forwarding Unit
// =========================================================
Hazard_Detection_Unit HDU_inst (
    .Rs1D(rs1), .Rs2D(rs2), .RdE(rdE), .MemtoRegE(MemtoRegE),
    .PCSrcE(PCSrcE), .PCWrite(PCWrite), .StallD(StallD), .FlushD(FlushD), .FlushE(FlushE)
);

Forwarding_Unit FU_inst (
    .Rs1E(rs1E), .Rs2E(rs2E), .RdM(rdM), .RegWriteM(RegWriteM), .RdW(rdW), .RegWriteW(RegWriteW),
    .ForwardAE(ForwardAE), .ForwardBE(ForwardBE)
);

endmodule