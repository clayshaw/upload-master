module Data_Memory(
    input             clk,
    input             MemWrite,
    input      [3:0]  ByteEnable,  
    input      [31:0] Addr,         
    input      [31:0] Write_Data,   
    output     [31:0] Read_Data      
);

    reg [31:0] ram [1023:0];

    initial begin
        $readmemh("Data.txt", ram);
    end

    assign Read_Data = ram[Addr[31:2]];

    always @(posedge clk) begin
        if (MemWrite) begin
            if (ByteEnable[0]) ram[Addr[31:2]][7:0]   <= Write_Data[7:0];
            if (ByteEnable[1]) ram[Addr[31:2]][15:8]  <= Write_Data[15:8];
            if (ByteEnable[2]) ram[Addr[31:2]][23:16] <= Write_Data[23:16];
            if (ByteEnable[3]) ram[Addr[31:2]][31:24] <= Write_Data[31:24];
        end
    end

endmodule