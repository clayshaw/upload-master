module Forwarding_Unit(
    input [4:0] Rs1E,
    input [4:0] Rs2E,
    input [4:0] RdM,
    input       RegWriteM,
    input [4:0] RdW,
    input       RegWriteW,
    output reg [1:0] ForwardAE,
    output reg [1:0] ForwardBE
);
    always @(*) begin
        // 預設不前遞（使用來自 ID/EX 暫存器的原始暫存器值）
        ForwardAE = 2'b00;
        ForwardBE = 2'b00;
        
        // ---- Forward A 邏輯 ----
        // 1. EX 衝突（來自 MEM 階段的前遞，優先權最高）
        if (RegWriteM && (RdM != 5'd0) && (RdM == Rs1E)) begin
            ForwardAE = 2'b10;
        end
        // 2. MEM 衝突（來自 WB 階段的前遞）
        else if (RegWriteW && (RdW != 5'd0) && (RdW == Rs1E)) begin
            ForwardAE = 2'b01;
        end
        
        // ---- Forward B 邏輯 ----
        // 1. EX 衝突（來自 MEM 階段的前遞，優先權最高）
        if (RegWriteM && (RdM != 5'd0) && (RdM == Rs2E)) begin
            ForwardBE = 2'b10;
        end
        // 2. MEM 衝突（來自 WB 階段的前遞）
        else if (RegWriteW && (RdW != 5'd0) && (RdW == Rs2E)) begin
            ForwardBE = 2'b01;
        end
    end
endmodule