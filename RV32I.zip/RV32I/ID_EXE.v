module ID_EXE(
    input clk, rst_n, FlushE,
    input RegWriteD,
    input [1:0] MemtoRegD,
    input MemWriteD, JumpD, BranchD,
    input ALUSrcAD,         
    input JalrD,            
    input [3:0]  ALUControlD,
    input [1:0]  ControlD,
    input ALUSrcD,
    input [2:0]  funct3D,   
    input [31:0] read_data1D, read_data2D, PCD,
    input [4:0]  Rs1D, Rs2D, RdD,
    input [31:0] immExD,
    
    output reg RegWriteE,
    output reg [1:0] MemtoRegE,
    output reg MemWriteE, JumpE, BranchE,
    output reg ALUSrcAE,    
    output reg JalrE,       
    output reg [3:0]  ALUControlE,
    output reg [1:0]  ControlE,
    output reg ALUSrcE,
    output reg [2:0]  funct3E, 
    output reg [31:0] read_data1E, read_data2E, PCE,
    output reg [4:0]  Rs1E, Rs2E, RdE,
    output reg [31:0] immExE
);
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        RegWriteE <= 0; MemtoRegE <= 0; MemWriteE <= 0;
        JumpE <= 0; BranchE <= 0; ALUSrcAE <= 0; JalrE <= 0;
        ALUControlE <= 0; ControlE <= 0; ALUSrcE <= 0; funct3E <= 0;
        read_data1E <= 0; read_data2E <= 0; PCE <= 0;
        Rs1E <= 0; Rs2E <= 0; RdE <= 0; immExE <= 0;
    end else if (FlushE) begin
        RegWriteE <= 0; MemtoRegE <= 0; MemWriteE <= 0;
        JumpE <= 0; BranchE <= 0; ALUSrcAE <= 0; JalrE <= 0;
        ALUControlE <= 0; ControlE <= 0; ALUSrcE <= 0; funct3E <= 0;
        read_data1E <= 0; read_data2E <= 0; PCE <= 0;
        Rs1E <= 0; Rs2E <= 0; RdE <= 0; immExE <= 0;
    end else begin
        RegWriteE <= RegWriteD; MemtoRegE <= MemtoRegD; MemWriteE <= MemWriteD;
        JumpE <= JumpD; BranchE <= BranchD; ALUSrcAE <= ALUSrcAD; JalrE <= JalrD;
        ALUControlE <= ALUControlD; ControlE <= ControlD; ALUSrcE <= ALUSrcD; funct3E <= funct3D;
        read_data1E <= read_data1D; read_data2E <= read_data2D; PCE <= PCD;
        Rs1E <= Rs1D; Rs2E <= Rs2D; RdE <= RdD; immExE <= immExD;
    end
end
endmodule