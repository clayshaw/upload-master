module IF_ID(
    input clk,
    input rst_n,
    input StallD,
    input FlushD,
    input [31:0] PCF,
    input [31:0] PCPlus4F,
    input [31:0] instrF,
    
    output reg [31:0] PCD,
    output reg [31:0] PCPlus4D,
    output reg [31:0] instrD
);
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        PCD      <= 32'd0;
        PCPlus4D <= 32'd0;
        instrD   <= 32'd0;
    end else if (FlushD) begin
        PCD      <= 32'd0;
        PCPlus4D <= 32'd0;
        instrD   <= 32'd0; 
    end else if (!StallD) begin
        PCD      <= PCF;
        PCPlus4D <= PCPlus4F;
        instrD   <= instrF;
    end
end
endmodule