module project1 (
    // 對應你提供的腳位名稱
    input  wire        CLOCK_50,
    input  wire [17:0] SW,
    input  wire [3:0]  KEY,
    output wire [17:0] LEDR,
    output wire [7:0]  LEDG,
    output wire [6:0]  HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7,
    output wire [7:0]  LCD_DATA,
    output wire        LCD_EN, LCD_ON, LCD_RS, LCD_RW, LCD_BLON,
    output wire        EEP_I2C_SCLK, 
    inout  wire        EEP_I2C_SDAT
);

    // ==========================================
    // 1. 產生 1Hz 時脈 (除頻器)
    // ==========================================
    // 50MHz / 50,000,000 = 1Hz (1秒切換一次)
    reg [25:0] clk_cnt;
    reg clk_1Hz;
    always @(posedge CLOCK_50 or negedge KEY[0]) begin
        if (!KEY[0]) begin
            clk_cnt <= 26'd0;
            clk_1Hz <= 1'b0;
        end else if (clk_cnt == 26'd24_999_999) begin
            clk_cnt <= 26'd0;
            clk_1Hz <= ~clk_1Hz;
        end else begin
            clk_cnt <= clk_cnt + 1'b1;
        end
    end

    // ==========================================
    // 2. 實體化交通控制核心狀態機 (FSM)
    // ==========================================
    wire [2:0] ns_lights;
    wire [2:0] ew_lights;
    wire [7:0] ns_count;
    wire [7:0] ew_count;

    traffic_fsm fsm_inst (
        .clk_1Hz(clk_1Hz),
        .rst_n(KEY[0]),
        // DE2-115 按鈕按下是 0，放開是 1，所以加上反相器 (~)
        .pedestrian_trig(~KEY[1]), 
        .emergency_trig(~KEY[2]),
        .ns_flow(SW[7:0]),    // 讀取右半邊指撥開關
        .ew_flow(SW[15:8]),   // 讀取左半邊指撥開關
        .ns_lights(ns_lights),
        .ew_lights(ew_lights),
        .ns_count(ns_count),
        .ew_count(ew_count)
    );

    // ==========================================
    // 3. 實體 LED 燈號對應 (紅綠燈視覺化)
    // ==========================================
    // ns_lights: [2]紅, [1]黃, [0]綠
    assign LEDR[17] = ns_lights[2]; // 南北紅燈
    assign LEDR[16] = ns_lights[1]; // 南北黃燈
    assign LEDG[7]  = ns_lights[0]; // 南北綠燈

    assign LEDR[0]  = ew_lights[2]; // 東西紅燈
    assign LEDR[1]  = ew_lights[1]; // 東西黃燈
    assign LEDG[0]  = ew_lights[0]; // 東西綠燈

    // 關閉沒用到的 LED，避免恆亮
    assign LEDR[15:2] = 14'd0;
    assign LEDG[6:1]  = 6'd0;

    // ==========================================
    // 4. 七段顯示器 (顯示倒數秒數)
    // ==========================================
    // 將 8-bit 二進位數值轉換為十位數與個位數 (除以 10 與取餘數)
    wire [3:0] ns_tens = ns_count / 10;
    wire [3:0] ns_ones = ns_count % 10;
    wire [3:0] ew_tens = ew_count / 10;
    wire [3:0] ew_ones = ew_count % 10;

    // 呼叫七段顯示器解碼模組
    seg7_decoder hex7_inst (.bcd(ns_tens), .seg(HEX7));
    seg7_decoder hex6_inst (.bcd(ns_ones), .seg(HEX6));
    seg7_decoder hex1_inst (.bcd(ew_tens), .seg(HEX1));
    seg7_decoder hex0_inst (.bcd(ew_ones), .seg(HEX0));

    // 關閉中間沒用到的七段顯示器 (DE2-115 是低電位亮，給 1 關閉)
    assign HEX5 = 7'b1111111;
    assign HEX4 = 7'b1111111;
    assign HEX3 = 7'b1111111;
    assign HEX2 = 7'b1111111;

    // ==========================================
    // 5. LCD 預設狀態配置
    // ==========================================
    // 給予固定的預設值，避免未驅動時 LCD 螢幕亂閃或產生雜訊
    assign LCD_ON   = 1'b1;
    assign LCD_BLON = 1'b1;
    assign LCD_EN   = 1'b0;
    assign LCD_RS   = 1'b0;
    assign LCD_RW   = 1'b0;
    assign LCD_DATA = 8'h00;
    
    // EEPROM 腳位預設輸出高阻抗
    assign EEP_I2C_SCLK = 1'bz;
    assign EEP_I2C_SDAT = 1'bz;

endmodule

// ==========================================
// 附屬模組：七段顯示器 BCD 解碼器
// ==========================================
module seg7_decoder (
    input  wire [3:0] bcd,
    output reg  [6:0] seg
);
    // DE2-115 上的七段顯示器是「共陽極」，0 代表亮，1 代表滅
    always @(*) begin
        case (bcd)
            4'd0: seg = 7'b1000000;
            4'd1: seg = 7'b1111001;
            4'd2: seg = 7'b0100100;
            4'd3: seg = 7'b0110000;
            4'd4: seg = 7'b0011001;
            4'd5: seg = 7'b0010010;
            4'd6: seg = 7'b0000010;
            4'd7: seg = 7'b1111000;
            4'd8: seg = 7'b0000000;
            4'd9: seg = 7'b0010000;
            default: seg = 7'b1111111; // 超過範圍時全暗
        endcase
    end
endmodule