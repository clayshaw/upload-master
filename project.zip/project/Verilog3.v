module traffic_fsm (
    input wire clk_1Hz,          // 1秒為單位的時脈訊號 (由 project1 分頻器提供)
    input wire rst_n,            // 硬體重設訊號 (低電位觸發，接 KEY[0])
    input wire pedestrian_trig,  // 行人過馬路觸發 (高電位有效，已在頂層反相)
    input wire emergency_trig,   // 緊急車輛觸發 (高電位有效，已在頂層反相)
    input wire [7:0] ns_flow,    // 南北向指撥開關輸入 (接 SW[7:0])
    input wire [7:0] ew_flow,    // 東西向指撥開關輸入 (接 SW[15:8])
    
    output reg [2:0] ns_lights,  // 南北向燈號 [2]:紅, [1]:黃, [0]:綠
    output reg [2:0] ew_lights,  // 東西向燈號 [2]:紅, [1]:黃, [0]:綠
    output reg [7:0] ns_count,   // 南北向七段顯示器倒數秒數
    output reg [7:0] ew_count    // 東西向七段顯示器倒數秒數
);

    // ==========================================
    // 1. 狀態定義 (使用獨熱碼 One-Hot Encoding 提高 FPGA 穩定度)
    // ==========================================
    localparam S_NS_GREEN  = 3'd0; // 南北綠燈、東西紅燈
    localparam S_NS_YELLOW = 3'd1; // 南北黃燈、東西紅燈
    localparam S_EW_GREEN  = 3'd2; // 南北紅燈、東西綠燈
    localparam S_EW_YELLOW = 3'd3; // 南北紅燈、東西黃燈
    localparam S_EMERGENCY = 3'd4; // 緊急狀態 (雙向全紅燈)

    reg [2:0] current_state, next_state;
    reg [7:0] countdown; // 內部倒數計時器

    // ==========================================
    // 2. 動態時間防呆機制 (確保 SW=0 時不會卡死)
    // ==========================================
    wire [7:0] actual_ns_time = (ns_flow < 8'd5) ? 8'd5 : ns_flow;
    wire [7:0] actual_ew_time = (ew_flow < 8'd5) ? 8'd5 : ew_flow;


    // ==========================================
    // 3. 第一段：更新狀態與計時器 (時序邏輯)
    // ==========================================
    always @(posedge clk_1Hz or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= S_NS_GREEN;
            countdown     <= 8'd10; // 重設時預設倒數 10 秒
        end else if (emergency_trig) begin
            current_state <= S_EMERGENCY;
            countdown     <= 8'd0;  // 緊急狀態下時間不倒數
        end else begin
            // 行人模式處理：若綠燈剩餘時間大於 3 秒，強制縮短至 3 秒，讓路口趕快變黃燈
            if (pedestrian_trig && (countdown > 8'd3) && 
               (current_state == S_NS_GREEN || current_state == S_EW_GREEN)) begin
                countdown <= 8'd3;
            end 
            // 正常每秒倒數
            else if (countdown > 8'd0) begin
                countdown <= countdown - 8'd1;
            end 
            // 時間歸零，跳轉至下一個狀態並載入新時間
            else begin
                current_state <= next_state;
                case (next_state)
                    S_NS_GREEN:  countdown <= actual_ns_time; // 載入南北 SW 設定的時間
                    S_NS_YELLOW: countdown <= 8'd3;           // 黄燈固定 3 秒
                    S_EW_GREEN:  countdown <= actual_ew_time; // 載入東西 SW 設定的時間
                    S_EW_YELLOW: countdown <= 8'd3;           // 黃燈固定 3 秒
                    default:     countdown <= 8'd5;
                endcase
            end
        end
    end


    // ==========================================
    // 4. 第二段：狀態跳轉邏輯 (組合邏輯)
    // ==========================================
    always @(*) begin
        next_state = current_state;
        
        if (emergency_trig) begin
            next_state = S_EMERGENCY;
        end else if (countdown == 8'd0) begin
            case (current_state)
                S_NS_GREEN:  next_state = S_NS_YELLOW;
                S_NS_YELLOW: next_state = S_EW_GREEN;
                S_EW_GREEN:  next_state = S_EW_YELLOW;
                S_EW_YELLOW: next_state = S_NS_GREEN;
                S_EMERGENCY: next_state = S_NS_GREEN; // 緊急解除後從南北向重新開始
                default:     next_state = S_NS_GREEN;
            endcase
        end
    end


    // ==========================================
    // 5. 第三段：燈號與顯示秒數輸出 (組合邏輯)
    // ==========================================
    always @(*) begin
        // 預設值，防止產生 Latch
        ns_lights = 3'b100; // 紅燈
        ew_lights = 3'b100; // 紅燈
        ns_count  = countdown;
        ew_count  = countdown;

        case (current_state)
            S_NS_GREEN: begin
                ns_lights = 3'b001; // 南北綠
                ew_lights = 3'b100; // 東西紅
                // 東西向紅燈秒數 = 南北綠燈剩餘秒數 + 黃燈 3 秒
                ew_count  = countdown + 8'd3; 
            end
            
            S_NS_YELLOW: begin
                ns_lights = 3'b010; // 南北黃
                ew_lights = 3'b100; // 東西紅
                ew_count  = countdown; 
            end
            
            S_EW_GREEN: begin
                ns_lights = 3'b100; // 南北紅
                ew_lights = 3'b001; // 東西綠
                // 南北向紅燈秒數 = 東西綠燈剩餘秒數 + 黃燈 3 秒
                ns_count  = countdown + 8'd3;
            end
            
            S_EW_YELLOW: begin
                ns_lights = 3'b100; // 南北紅
                ew_lights = 3'b010; // 東西黃
                ns_count  = countdown;
            end
            
            S_EMERGENCY: begin
                ns_lights = 3'b100; // 強制全紅燈
                ew_lights = 3'b100; // 強制全紅燈
                ns_count  = 8'd0;
                ew_count  = 8'd0;
            end
        endcase
    end

endmodule