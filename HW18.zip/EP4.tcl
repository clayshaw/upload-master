# Copyright (C) 1991-2013 Altera Corporation
# Your use of Altera Corporation's design tools, logic functions 
# and other software and tools, and its AMPP partner logic 
# functions, and any output files from any of the foregoing 
# (including device programming or simulation files), and any 
# associated documentation or information are expressly subject 
# to the terms and conditions of the Altera Program License 
# Subscription Agreement, Altera MegaCore Function License 
# Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by 
# Altera or its authorized distributors.  Please refer to the 
# applicable agreement for further details.

# Quartus II 64-Bit Version 13.1.0 Build 162 10/23/2013 SJ Web Edition
# File: E:\PQuartus\MULT_Fast\EP4.tcl
# Generated on: Mon May 12 12:52:38 2025

package require ::quartus::project

set_location_assignment PIN_Y2 -to iCLK
set_location_assignment	PIN_Y23	-to	SW[17]
set_location_assignment	PIN_Y24	-to	SW[16]
set_location_assignment	PIN_AA22	-to	SW[15]
set_location_assignment	PIN_AA23	-to	SW[14]
set_location_assignment	PIN_AA24	-to	SW[13]
set_location_assignment	PIN_AB23	-to	SW[12]
set_location_assignment	PIN_AB24	-to	SW[11]
set_location_assignment	PIN_AC24	-to	SW[10]
set_location_assignment	PIN_AB25	-to	SW[9]
set_location_assignment	PIN_AC25	-to	SW[8]
set_location_assignment	PIN_AB26	-to	SW[7]
set_location_assignment	PIN_AD26	-to	SW[6]
set_location_assignment	PIN_AC26	-to	SW[5]
set_location_assignment	PIN_AB27	-to	SW[4]
set_location_assignment	PIN_AD27	-to	SW[3]
set_location_assignment	PIN_AC27	-to	SW[2]
set_location_assignment	PIN_AC28	-to	SW[1]
set_location_assignment	PIN_AB28	-to	SW[0]
set_location_assignment	PIN_R24	-to	iRST_N
set_location_assignment	PIN_N21	-to	KEY[2]
set_location_assignment	PIN_M21	-to	KEY[1]
set_location_assignment	PIN_M23	-to	PUSH
set_location_assignment	PIN_G21	-to	LEDG[7]
set_location_assignment	PIN_G22	-to	LEDG[6]
set_location_assignment	PIN_G20	-to	LEDG[5]
set_location_assignment	PIN_H21	-to	LEDG[4]
set_location_assignment	PIN_E24	-to	LEDG[3]
set_location_assignment	PIN_E25	-to	LEDG[2]
set_location_assignment	PIN_E22	-to	LEDG[1]
set_location_assignment	PIN_E21	-to	LEDG[0]
set_location_assignment	PIN_H22	-to	HEX0[6]
set_location_assignment	PIN_J22	-to	HEX0[5]
set_location_assignment	PIN_L25	-to	HEX0[4]
set_location_assignment	PIN_L26	-to	HEX0[3]
set_location_assignment	PIN_E17	-to	HEX0[2]
set_location_assignment	PIN_F22	-to	HEX0[1]
set_location_assignment	PIN_G18	-to	HEX0[0]
set_location_assignment	PIN_U24	-to	HEX1[6]
set_location_assignment	PIN_U23	-to	HEX1[5]
set_location_assignment	PIN_W25	-to	HEX1[4]
set_location_assignment	PIN_W22	-to	HEX1[3]
set_location_assignment	PIN_W21	-to	HEX1[2]
set_location_assignment	PIN_Y22	-to	HEX1[1]
set_location_assignment	PIN_M24	-to	HEX1[0]
set_location_assignment	PIN_W28	-to	HEX2[6]
set_location_assignment	PIN_W27	-to	HEX2[5]
set_location_assignment	PIN_Y26	-to	HEX2[4]
set_location_assignment	PIN_W26	-to	HEX2[3]
set_location_assignment	PIN_Y25	-to	HEX2[2]
set_location_assignment	PIN_AA26	-to	HEX2[1]
set_location_assignment	PIN_AA25	-to	HEX2[0]
set_location_assignment	PIN_Y19	-to	HEX3[6]
set_location_assignment	PIN_AF23	-to	HEX3[5]
set_location_assignment	PIN_AD24	-to	HEX3[4]
set_location_assignment	PIN_AA21	-to	HEX3[3]
set_location_assignment	PIN_AB20	-to	HEX3[2]
set_location_assignment	PIN_U21	-to	HEX3[1]
set_location_assignment	PIN_V21	-to	HEX3[0]
set_location_assignment	PIN_AE18	-to	HEX4[6]
set_location_assignment	PIN_AF19	-to	HEX4[5]
set_location_assignment	PIN_AE19	-to	HEX4[4]
set_location_assignment	PIN_AH21	-to	HEX4[3]
set_location_assignment	PIN_AG21	-to	HEX4[2]
set_location_assignment	PIN_AA19	-to	HEX4[1]
set_location_assignment	PIN_AB19	-to	HEX4[0]
set_location_assignment	PIN_AH18	-to	HEX5[6]
set_location_assignment	PIN_AF18	-to	HEX5[5]
set_location_assignment	PIN_AG19	-to	HEX5[4]
set_location_assignment	PIN_AH19	-to	HEX5[3]
set_location_assignment	PIN_AB18	-to	HEX5[2]
set_location_assignment	PIN_AC18	-to	HEX5[1]
set_location_assignment	PIN_AD18	-to	HEX5[0]
set_location_assignment	PIN_AC17	-to	HEX6[6]
set_location_assignment	PIN_AA15	-to	HEX6[5]
set_location_assignment	PIN_AB15	-to	HEX6[4]
set_location_assignment	PIN_AB17	-to	HEX6[3]
set_location_assignment	PIN_AA16	-to	HEX6[2]
set_location_assignment	PIN_AB16	-to	HEX6[1]
set_location_assignment	PIN_AA17	-to	HEX6[0]
set_location_assignment	PIN_AA14	-to	HEX7[6]
set_location_assignment	PIN_AG18	-to	HEX7[5]
set_location_assignment	PIN_AF17	-to	HEX7[4]
set_location_assignment	PIN_AH17	-to	HEX7[3]
set_location_assignment	PIN_AG17	-to	HEX7[2]
set_location_assignment	PIN_AE17	-to	HEX7[1]
set_location_assignment	PIN_AD17	-to	HEX7[0]
set_location_assignment	PIN_H15	-to	LEDR[17]
set_location_assignment	PIN_G16	-to	LEDR[16]
set_location_assignment	PIN_G15	-to	LEDR[15]
set_location_assignment	PIN_F15	-to	LEDR[14]
set_location_assignment	PIN_H17	-to	LEDR[13]
set_location_assignment	PIN_J16	-to	LEDR[12]
set_location_assignment	PIN_H16	-to	LEDR[11]
set_location_assignment	PIN_J15	-to	LEDR[10]
set_location_assignment	PIN_G17	-to	LEDR[9]
set_location_assignment	PIN_J17	-to	LEDR[8]
set_location_assignment	PIN_H19	-to	LEDR[7]
set_location_assignment	PIN_J19	-to	LEDR[6]
set_location_assignment	PIN_E18	-to	LEDR[5]
set_location_assignment	PIN_F18	-to	LEDR[4]
set_location_assignment	PIN_F21	-to	LEDR[3]
set_location_assignment	PIN_E19	-to	LEDR[2]
set_location_assignment	PIN_F19	-to	LEDR[1]
set_location_assignment	PIN_G19	-to	LEDR[0]
set_location_assignment PIN_M5 -to LCD_DATA[7]
set_location_assignment PIN_M3 -to LCD_DATA[6]
set_location_assignment PIN_K2 -to LCD_DATA[5]
set_location_assignment PIN_K1 -to LCD_DATA[4]
set_location_assignment PIN_K7 -to LCD_DATA[3]
set_location_assignment PIN_L2 -to LCD_DATA[2]
set_location_assignment PIN_L1 -to LCD_DATA[1]
set_location_assignment PIN_L3 -to LCD_DATA[0]
set_location_assignment PIN_L4 -to LCD_EN
set_location_assignment PIN_M1 -to LCD_RW
set_location_assignment PIN_M2 -to LCD_RS
set_location_assignment PIN_L5 -to LCD_ON
set_location_assignment PIN_L6 -to LCD_BLON