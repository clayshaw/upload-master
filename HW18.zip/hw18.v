module	hw18 (	//	Host Side
					iCLK,iRST_N,SW,PUSH,
					//	LCD Side
					LCD_DATA,LCD_RW,LCD_EN,LCD_RS	
					
					);
//	Host Side
input			iCLK,iRST_N;
input 		[4:0]SW;
input			PUSH;
//	LCD Side
output	[7:0]	LCD_DATA;
output			LCD_RW,LCD_EN,LCD_RS;
//	Internal Wires/Registers
reg	[4:0]	LUT_INDEX;
reg	[8:0]	LUT_DATA;
reg	[5:0]	mLCD_ST;
reg	[17:0]	mDLY;
reg			mLCD_Start;
reg	[7:0]	mLCD_DATA;
reg			mLCD_RS;
wire		mLCD_Done;

reg [7:0]txt1[15:0];
reg [7:0]txt2[15:0];
reg [7:0]txt3[15:0];
reg [7:0]txt4[15:0];

initial begin
	$readmemb("txt1.txt",txt1);
	$readmemb("txt2.txt",txt2);
	$readmemb("txt3.txt",txt3);
	$readmemb("txt4.txt",txt4);
end

parameter	LCD_INTIAL	=	0;
parameter 	LUT_SIZE		= 23;
parameter	LINE_SELECT = 6;
parameter	WRITE_DATA	= 7;

always@(posedge iCLK or negedge iRST_N)
begin
	if(!iRST_N)
	begin
		LUT_INDEX	<=	0;
		mLCD_ST		<=	0;
		mDLY		<=	0;
		mLCD_Start	<=	0;
		mLCD_DATA	<=	0;
		mLCD_RS		<=	0;
	end
	else
	begin
		if(LUT_INDEX<LUT_SIZE)
		begin
			case(mLCD_ST)
			0:	begin
					mLCD_DATA	<=	LUT_DATA[7:0];
					mLCD_RS		<=	LUT_DATA[8];
					mLCD_Start	<=	1;
					mLCD_ST		<=	1;
				end
			1:	begin
					if(mLCD_Done)
					begin
						mLCD_Start	<=	0;
						mLCD_ST		<=	2;					
					end
				end
			2:	begin
					if(mDLY<18'h3FFFE)
					mDLY	<=	mDLY+1;
					else
					begin
						mDLY	<=	0;
						mLCD_ST	<=	3;
					end
				end
			3:	begin
					LUT_INDEX	<=	LUT_INDEX+1;
					mLCD_ST	<=	0;
				end
			endcase
		end
		if(!PUSH) begin
			LUT_INDEX <= LINE_SELECT;
		end
	end
end
//LCD_CH_LINE:	LUT_DATA	<=	9'h0C0;
always
begin
	case(LUT_INDEX)
	//	Initial
	LCD_INTIAL+0:	LUT_DATA	<=	9'h038;
	LCD_INTIAL+1:	LUT_DATA	<=	9'h00C;
	LCD_INTIAL+2:	LUT_DATA	<=	9'h001;
	LCD_INTIAL+3:	LUT_DATA	<=	9'h006;
	LCD_INTIAL+4:	LUT_DATA	<=	9'h080;
	LINE_SELECT:	LUT_DATA <= (SW[4])? 9'h0C0 : 9'h080;
	WRITE_DATA+0:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[0]};
			2'd1: LUT_DATA <= {1'b1,txt2[0]};
			2'd2: LUT_DATA <= {1'b1,txt3[0]};
			2'd3: LUT_DATA <= {1'b1,txt4[0]};
		endcase
	end
	WRITE_DATA+1:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[1]};
			2'd1: LUT_DATA <= {1'b1,txt2[1]};
			2'd2: LUT_DATA <= {1'b1,txt3[1]};
			2'd3: LUT_DATA <= {1'b1,txt4[1]};
		endcase
	end
	WRITE_DATA+2:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[2]};
			2'd1: LUT_DATA <= {1'b1,txt2[2]};
			2'd2: LUT_DATA <= {1'b1,txt3[2]};
			2'd3: LUT_DATA <= {1'b1,txt4[2]};
		endcase
	end
	WRITE_DATA+3:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[3]};
			2'd1: LUT_DATA <= {1'b1,txt2[3]};
			2'd2: LUT_DATA <= {1'b1,txt3[3]};
			2'd3: LUT_DATA <= {1'b1,txt4[3]};
		endcase
	end
	WRITE_DATA+4:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[4]};
			2'd1: LUT_DATA <= {1'b1,txt2[4]};
			2'd2: LUT_DATA <= {1'b1,txt3[4]};
			2'd3: LUT_DATA <= {1'b1,txt4[4]};
		endcase
	end
	WRITE_DATA+5:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[5]};
			2'd1: LUT_DATA <= {1'b1,txt2[5]};
			2'd2: LUT_DATA <= {1'b1,txt3[5]};
			2'd3: LUT_DATA <= {1'b1,txt4[5]};
		endcase
	end
	WRITE_DATA+6:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[6]};
			2'd1: LUT_DATA <= {1'b1,txt2[6]};
			2'd2: LUT_DATA <= {1'b1,txt3[6]};
			2'd3: LUT_DATA <= {1'b1,txt4[6]};
		endcase
	end
	WRITE_DATA+7:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[7]};
			2'd1: LUT_DATA <= {1'b1,txt2[7]};
			2'd2: LUT_DATA <= {1'b1,txt3[7]};
			2'd3: LUT_DATA <= {1'b1,txt4[7]};
		endcase
	end
	WRITE_DATA+0:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[0]};
			2'd1: LUT_DATA <= {1'b1,txt2[0]};
			2'd2: LUT_DATA <= {1'b1,txt3[0]};
			2'd3: LUT_DATA <= {1'b1,txt4[0]};
		endcase
	end
	WRITE_DATA+8:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[8]};
			2'd1: LUT_DATA <= {1'b1,txt2[8]};
			2'd2: LUT_DATA <= {1'b1,txt3[8]};
			2'd3: LUT_DATA <= {1'b1,txt4[8]};
		endcase
	end
	WRITE_DATA+9:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[9]};
			2'd1: LUT_DATA <= {1'b1,txt2[9]};
			2'd2: LUT_DATA <= {1'b1,txt3[9]};
			2'd3: LUT_DATA <= {1'b1,txt4[9]};
		endcase
	end
	WRITE_DATA+10:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[10]};
			2'd1: LUT_DATA <= {1'b1,txt2[10]};
			2'd2: LUT_DATA <= {1'b1,txt3[10]};
			2'd3: LUT_DATA <= {1'b1,txt4[10]};
		endcase
	end
	WRITE_DATA+11:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[11]};
			2'd1: LUT_DATA <= {1'b1,txt2[11]};
			2'd2: LUT_DATA <= {1'b1,txt3[11]};
			2'd3: LUT_DATA <= {1'b1,txt4[11]};
		endcase
	end
	WRITE_DATA+12:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[12]};
			2'd1: LUT_DATA <= {1'b1,txt2[12]};
			2'd2: LUT_DATA <= {1'b1,txt3[12]};
			2'd3: LUT_DATA <= {1'b1,txt4[12]};
		endcase
	end
	WRITE_DATA+13:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[13]};
			2'd1: LUT_DATA <= {1'b1,txt2[13]};
			2'd2: LUT_DATA <= {1'b1,txt3[13]};
			2'd3: LUT_DATA <= {1'b1,txt4[13]};
		endcase
	end
	WRITE_DATA+14:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[14]};
			2'd1: LUT_DATA <= {1'b1,txt2[14]};
			2'd2: LUT_DATA <= {1'b1,txt3[14]};
			2'd3: LUT_DATA <= {1'b1,txt4[14]};
		endcase
	end
	WRITE_DATA+15:	begin
		case(SW[1:0])
			2'd0: LUT_DATA <= {1'b1,txt1[15]};
			2'd1: LUT_DATA <= {1'b1,txt2[15]};
			2'd2: LUT_DATA <= {1'b1,txt3[15]};
			2'd3: LUT_DATA <= {1'b1,txt4[15]};
		endcase
	end
	default:		LUT_DATA	<=	9'h120;
	endcase
end

LCD_Controller 		u0	(	//	Host Side
							.iDATA(mLCD_DATA),
							.iRS(mLCD_RS),
							.iStart(mLCD_Start),
							.oDone(mLCD_Done),
							.iCLK(iCLK),
							.iRST_N(iRST_N),
							//	LCD Interface
							.LCD_DATA(LCD_DATA),
							.LCD_RW(LCD_RW),
							.LCD_EN(LCD_EN),
							.LCD_RS(LCD_RS)	);

endmodule