module SW2HEX(
    input [3:0]sw,
    output reg [6:0]HEX0,
    output reg [6:0]HEX1
);

wire [4:0]num = {sw[3],sw};

always @(*) begin
    if(num[4])begin
        HEX0 = 7'b0111111;
        HEX1 = decoder((~num)+1);
    end else begin
        HEX0 = 7'b1111111;
        HEX1 = decoder(num);
    end
end

function[6:0] decoder;
    input [4:0]number;
    begin
        case (number)
            5'd0: decoder = 7'b1000000; 
            5'd1: decoder = 7'b1111001; 
            5'd2: decoder = 7'b0100100;
            5'd3: decoder = 7'b0110000;
            5'd4: decoder = 7'b0011001;
            5'd5: decoder = 7'b0010010;
            5'd6: decoder = 7'b0000010;
            5'd7: decoder = 7'b1111000;
            5'd8: decoder = 7'b0000000; 
            5'd9: decoder = 7'b0010000; 
            default: decoder = 7'b1111111; 
        endcase
    end
    
endfunction

endmodule