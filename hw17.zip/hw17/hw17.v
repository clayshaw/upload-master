module hw17(
    input         CLOCK_50,
    input  [17:0] SW,
    input  [3:0]  KEY,
    output [6:0]  HEX4, HEX5, HEX6, HEX7,
    output reg [6:0] HEX0, HEX1, HEX2
);


SW2HEX H1(SW[17:14],HEX7,HEX6);
SW2HEX H2(SW[13:10],HEX5,HEX4);

reg signed [8:0] acc;
reg [1:0]state;
reg [7:0] previous;
reg move;
reg run;



wire [4:0] multiplicand = {SW[17], SW[17:14]}; 
wire [4:0] add_result   = acc[8:4] + (acc[0] ? multiplicand : 5'b0);
wire [4:0] sub_result   = acc[8:4] - (acc[0] ? multiplicand : 5'b0);
wire signed [8:0] tmp = acc[8] ? -acc : acc;



always @(posedge CLOCK_50) begin
    previous <= SW[7:0];
    move <= (previous != SW[7:0]);
end

always @(posedge CLOCK_50) begin
    if(move) begin
        run   <= 1'b1;
        state <= 2'b0;
        acc   <= {5'b0, SW[13:10]}; 
    end else if(run) begin
        state <= state + 2'b1;
        case (state)
            2'b00, 2'b01, 2'b10: begin
                acc <= {add_result[4], add_result, acc[3:1]}; 
            end
            2'b11: begin
                acc <= {sub_result[4], sub_result, acc[3:1]}; 
                run <= 1'b0;
            end
        endcase
    end
end

always @(posedge CLOCK_50) begin
    
    if(!KEY[0])begin
        HEX2 <= acc[8] ? 7'b0111111:7'b1111111;
        HEX1 <= decoder((tmp/10) %10);
        HEX0 <= decoder(tmp %10);
    end
end

function[6:0] decoder;
    input [8:0] number;
    begin
        case (number)
            9'd0: decoder = 7'b1000000; 
            9'd1: decoder = 7'b1111001; 
            9'd2: decoder = 7'b0100100;
            9'd3: decoder = 7'b0110000;
            9'd4: decoder = 7'b0011001;
            9'd5: decoder = 7'b0010010;
            9'd6: decoder = 7'b0000010;
            9'd7: decoder = 7'b1111000;
            9'd8: decoder = 7'b0000000; 
            9'd9: decoder = 7'b0010000; 
            default: decoder = 7'b1111111; 
        endcase
    end
    
endfunction

    
endmodule