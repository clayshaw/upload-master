module hw15(
	input CLOCK_50,
	input [17:0]SW, 		// manual mode input
	input [3:0]KEY,
	output [6:0]HEX0,
	output [6:0]HEX1,
	output [6:0]HEX2,
	output [6:0]HEX3
);

wire clk = 			 CLOCK_50;
wire [3:0]sw = 	 SW[3:0]; 		// manual mode input
wire direction = 	 SW[17];		// switch
wire mode = 		 SW[16];				// switch mode
wire KEY_digital = KEY[0];	// button
wire rst = 			 KEY[3];				// button
wire [6:0]hex0 = 	 HEX0;
wire [6:0]hex1 = 	 HEX1;
wire [6:0]hex2 = 	 HEX2;
wire [6:0]hex3 = 	 HEX3;

wire divided_clk;
wire [3:0]number;
wire [3:0] display_in;
wire [6:0]digital;
wire OKEY;
wire OKEY_rst;
reg shift_trigger;

assign display_in = (mode == 1'b1) ? number : sw;



reg divided_clk_delay;
always @(posedge clk) divided_clk_delay <= divided_clk;
wire auto_trigger = (divided_clk && !divided_clk_delay); 

divider divi(
	.rst(OKEY_rst),
	.clk(clk),
	.divided_clk(divided_clk)
);

counter_4bits c(
	.rst(OKEY_rst),
	.clk(auto_trigger),
	.number(number)
);

decoder deco(
	.number(display_in),
	.hex(digital)
);

Key_detect k1(
	.clk(clk),
	.KEY(rst),
	.OKEY(OKEY_rst)
);

Key_detect k2(
	.clk(clk),
	.KEY(KEY_digital),
	.OKEY(OKEY)
);




always @(*) begin
    if (mode == 1'b1) 
        shift_trigger <= auto_trigger; 
    else 
        shift_trigger <= ~OKEY; // OKEY 是負向脈衝，!OKEY 就是正向脈衝
end

shifter sh(
	.rst(OKEY_rst),
	.clk(clk),
	.trigger(shift_trigger),
	.direction(direction),
	.digital(digital),
	.hex0(hex0),
	.hex1(hex1),
	.hex2(hex2),
	.hex3(hex3)
);





endmodule

