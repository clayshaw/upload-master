module divider(
	input rst,
	input clk,
	output reg divided_clk
);

reg [25:0]ticks;

initial begin
	ticks = 0;
	divided_clk = 0;
end

always @(posedge clk or negedge rst) begin
	if(!rst) begin
		ticks <= 0;
		divided_clk <= 0;
	end else begin
		if(ticks == 26'd24_999_999) begin
			divided_clk <= ~divided_clk;
			ticks <= 0;
		end else begin
			ticks <= ticks + 1;
		end
	end
end

endmodule
