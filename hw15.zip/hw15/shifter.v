module shifter(
	input rst, 
	input clk,
	input direction,
	input trigger,
	input [6:0]digital,
	output reg [6:0]hex0,
	output reg [6:0]hex1,
	output reg [6:0]hex2,
	output reg [6:0]hex3
);

always @(posedge trigger or negedge rst) begin
	if(!rst) begin
		{hex3, hex2, hex1, hex0} <= {7'b0,7'b0,7'b0,7'b0};
	end else begin
		if (trigger) begin 
			if (direction == 1'b0) begin
				{hex3, hex2, hex1, hex0} <= {hex2, hex1, hex0, digital};
			end else begin
				{hex3, hex2, hex1, hex0} <= {digital, hex3, hex2, hex1};
			end
		end
	end
end

endmodule
