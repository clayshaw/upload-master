module decoder(
	input [3:0] number,
	output reg [6:0] hex
);

always @(*) begin
	case (number)
		4'h0: hex = 7'b0111111;
		4'h1: hex = 7'b0000110;
		4'h2: hex = 7'b1011011;
		4'h3: hex = 7'b1001111;
		4'h4: hex = 7'b1100110;
		4'h5: hex = 7'b1101101;
		4'h6: hex = 7'b1111101;
		4'h7: hex = 7'b0000111;
		4'h8: hex = 7'b1111111;
		4'h9: hex = 7'b1101111;
		4'hA: hex = 7'b1110111;
		4'hB: hex = 7'b1111100;
		4'hC: hex = 7'b0111001;
		4'hD: hex = 7'b1011110;
		4'hE: hex = 7'b1111001;
		4'hF: hex = 7'b1110001;
		default: hex = 7'b0000000; 
	endcase
end

endmodule
