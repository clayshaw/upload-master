module counter_4bits(
	input rst,
	input clk,
	output reg [3:0]number
);

always @(posedge clk or negedge rst) begin
	if(!rst) begin
		number = 0;
	end else begin
		 if (number >= 4'b1001)
			  number <= 4'b0000;
		 else
			  number <= number + 1;
	end
end

endmodule