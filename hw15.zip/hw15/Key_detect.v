module Key_detect(
	input clk,
	input KEY,
	output reg OKEY
);

reg previous_state;

always @(posedge clk) begin
	if(previous_state == 1'b1 && KEY == 1'b0) begin
		OKEY <= 0;
	end else begin
		OKEY <= 1;
	end
	previous_state <= KEY;
end

endmodule
